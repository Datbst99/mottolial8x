<div class="border p-3 wp-search-product">
    <?php if(count($products) > 0): ?>
        <div class="row  mb-3 border-bottom font-weight-bold" >
            <div class="col-md-3">
                <div class="img" >
                    Hình ảnh
                </div>
            </div>
            <div class="col-md-5">
                <div class="name" >
                    Tên sản phẩm
                </div>
            </div>
            <div class="col-md-2">
                <div class="phone" > Mã sản phẩm</div>
            </div>
            <div class="col-md-2 text-right">
                Chọn
            </div>
        </div>
        <div id="remove-select">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row mb-2 item-search-product">
                    <div class="col-md-3">
                        <div class="img">
                            <img src="<?php echo e($product->thumbnail); ?>" alt=" <?php echo e($product->name); ?>" style="width: 50px; height: 50px">
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="name" >
                            <?php echo e($product->name); ?>

                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="phone" ><?php echo e($product->code); ?></div>
                    </div>
                    <div class="col-md-2 text-right">
                        <button class="btn btn-primary " onclick="renderClassify(this, <?php echo e($product->id); ?>)">Chọn</button>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="alert alert-warning m-0" role="alert">
            Không tìm thấy sản phẩm.
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\mottolial_8x\resources\views/admin/invoice/_search_product.blade.php ENDPATH**/ ?>