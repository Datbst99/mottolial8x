<?php $__env->startSection('content'); ?>
    <div class="alert alert-success" role="alert">
        Xin chào admin
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mottolial_8x\resources\views/admin/index.blade.php ENDPATH**/ ?>