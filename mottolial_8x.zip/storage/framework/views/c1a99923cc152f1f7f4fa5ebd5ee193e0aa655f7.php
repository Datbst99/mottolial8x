<div class="border mt-3 p-3">
    <?php if(count($users) > 0): ?>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="d-flex justify-content-between mb-2 align-items-center">
                <div class="user-name" style="width: 40%">
                    <?php echo e($user->name); ?>

                </div>
                <div class="phone" style="width: 20%"><?php echo e($user->phone); ?></div>
                <div class="address" style="width: 35%"><?php echo e($user->address); ?></div>
                <div>
                    <button class="btn btn-primary " onclick="getUser(this, <?php echo e($user->id); ?>)">Chọn</button>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="alert alert-warning m-0" role="alert">
            Không tìm thấy khách hàng. Vui lòng tạo mới khách hàng nếu không tìm thấy
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\mottolial_8x\resources\views/admin/invoice/_list_user.blade.php ENDPATH**/ ?>