<div class="form-group">
    <input type="text" value="<?php echo e($product->id); ?>" class="d-none select-product">
    <label for="title">Chọn loại sản phẩm</label>
    <select name="classifyProduct" id="" class="select-classify form-control" style="width: 100%">
        <option value="" selected disabled>--Chọn loại sản phẩm--</option>
        <?php $__currentLoopData = $classifies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($classify->id); ?>"><?php echo e($classify->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

</div>
<?php /**PATH C:\xampp\htdocs\mottolial_8x\resources\views/admin/invoice/_classify.blade.php ENDPATH**/ ?>