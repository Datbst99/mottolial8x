<?php $__env->startSection('title', 'Cập nhật sản phẩm'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h3 class="page-title"> Cập nhật sản phẩm </h3>
        <?php echo e(Breadcrumbs::render('admin.product.edit')); ?>

    </div>
    <div class="card">
        <form action="<?php echo e(route('product.update', ['id' => $product->id])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="form-group">
                    <label for="">Tên sản phẩm</label>
                    <input type="text" name="name" class="form-control" placeholder="Nhập tên sản phẩm" value="<?php echo e($product->name); ?>">
                </div>
                <div class="form-group">
                    <label for="">Code</label>
                    <input type="text" name="code" class="form-control" placeholder="Nhập mã sản phẩm" value="<?php echo e($product->code); ?>">
                </div>
                <div class="form-group">
                    <label for="description">Mô tả</label>
                    <textarea name="description" id="description" class="form-control" rows="5" placeholder="Nhập mô tả" > <?php echo e($product->description); ?> </textarea>
                </div>
                <div class="form-group">
                    <label for="">Hình ảnh</label>
                    <div>
                        <img src="<?php echo e($product->thumbnail ?? '/assets/images/default.png'); ?>" alt="" style="width: 150px; height: 150px" id="btn_file_add">
                        <input type="text" class="form-control d-none" id="file_name_add" name="thumbnail" placeholder="Tên file" value="<?php echo e(old('thumbnail')); ?>">
                    </div>
                   
                </div>
                <div class="form-group">
                    <label for="">Danh mục</label>
                    <?php echo Form::select('category', $categories, $product->category_id, ['class' => 'form-control', 'placeholder' => '--Chọn danh mục--']); ?>

                </div>
                <div class="form-group">
                    <label for="">Phân loại sản phẩm</label>
                    <div id="classify">
                        <?php $__currentLoopData = $product->classify; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-between wp-classify">
                                <div class="item-add">
                                    <input type="text" name="classifyName[]" placeholder="Nhập tên phân loại" class="form-control" value="<?php echo e($classify->name); ?>">
                                </div>
                                <div class="item-add">
                                    <input type="text" name="price[]" placeholder="Nhập giá sản phẩm" class="form-control" value="<?php echo e($classify->price); ?>">
                                </div>
                                <div class="item-add">
                                    <input type="text" name="sale_price[]" placeholder="Nhập giá khuyến mại" class="form-control" value="<?php echo e($classify->sale_price); ?>">
                                </div>
                                <div class="item-add">
                                    <input type="number" name="amount[]" placeholder="Số lượng" class="form-control" value="<?php echo e($classify->amount); ?>">
                                </div>
                                <div class="delete-item" onclick="deleteItem(this)">
                                    <i class="mdi mdi-delete"></i>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="add-classify" onclick="addClassify()">
                        <i class="mdi mdi-plus-circle-outline mr-2"></i> <span style="font-size: 18px"> Thêm phân loại sản phẩm</span>
                    </div>
                </div>

                <div class="border-top mt-5 pt-3">
                    <a href="<?php echo e(route('product.index')); ?>" class="btn btn-secondary">Hủy</a>
                    <button type="submit" class="btn btn-success">Cập nhật</button>
                </div>
            </div>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo Html::script('/assets/vendors/ckfinder/ckfinder.js'); ?>

    <script>
        var button1 = document.getElementById('btn_file_add');
        button1.onclick = function() {
            selectFileWithCKFinder('file_name_add');
        };

        function selectFileWithCKFinder( elementId ) {
            CKFinder.modal({
                chooseFiles: true,
                width: 800,
                height: 600,
                onInit: function (finder) {
                    finder.on('files:choose', function (evt) {
                        var url = '';
                        for (i = 0; i < evt.data.files.models.length; i++) {
                            var file = evt.data.files.models[i];
                            var tempurl = file.getUrl();
                            url += tempurl;
                        }
                        var output = document.getElementById(elementId);
                        output.value = url;
                        $('#btn_file_add').attr('src', url)
                    });
                    finder.on('file:choose:resizedImage', function (evt) {
                        var url = '';
                        for (i = 0; i < evt.data.files.models.length; i++) {
                            var file = evt.data.files.models[i];
                            var tempurl = file.getUrl();
                            url += tempurl;
                        }
                        var output = document.getElementById(elementId);
                        output.value = url;
                        $('#btn_file_add').attr('src', url)
                    });
                }
            })
        }

        function addClassify() {
            $.ajax({
                url: '/admin/product/classify',
                method: 'post',
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content')
                }
            }).done(function (res) {
                $('#classify').append(res.data)
            }).fail(function (xhr) {
                console.log(xhr)
            })
        }

        function deleteItem(obj){
            var count = $('.delete-item').parent('.wp-classify').length
            if(count > 1) {
                $(obj).parent().remove()
            }
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mottolial_8x\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>