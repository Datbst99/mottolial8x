<div class="wp-classify">
    <div class="mb-3">
          <?php echo e($product->name); ?> -- Loại: <?php echo e($classify->name); ?>

    </div>
    <div class="d-flex justify-content-between align-items-center item-order">

        <div class="item-add d-none">
            <div class="form-group">
                <label for=""></label>
                <input type="text" name="classify[<?php echo e($product->id); ?>]" class="form-control" value="<?php echo e($classify->id); ?>">
            </div>
        </div>
        <div class="item-add">
            <div class="form-group">
                <label for="">Số lượng</label>
                <input type="number" name="amount[<?php echo e($product->id); ?>]" placeholder="Số lượng" class="form-control amount-product" value="1" onchange="configPrice(this, 'amount')">
            </div>
        </div>
        <div class="item-add">
            <div class="form-group">
                <label for="">Giá</label>
                <input type="text" name="price[<?php echo e($product->id); ?>]" placeholder="Giá" class="form-control price-product disabled" value="<?php echo e($classify->price); ?>" >
            </div>
        </div>
        <div class="item-add">
            <div class="form-group">
                <label for="">Giá khuyến mại</label>
                <input type="text" name="sale_price[<?php echo e($product->id); ?>]" placeholder="Nhập giá khuyến mại" class="form-control sale-price" value="<?php echo e($classify->sale_price); ?>" onchange="configPrice(this, 'sale')">
            </div>
        </div>

        <div class="item-add text-center">
            <div class="form-group">
                <label for="">Thành tiền</label>
                <div style="padding: 5px 0" id="total-price">
                    <?php echo e(number_format($classify->sale_price ?  $classify->sale_price : $classify->price)); ?> đ
                </div>
            </div>
        </div>
        <div class="delete-item mt-1" onclick="deleteItem(this)">
            <i class="mdi mdi-delete"></i>
        </div>

    </div>

</div>
<?php /**PATH C:\xampp\htdocs\mottolial_8x\resources\views/admin/invoice/_info_product.blade.php ENDPATH**/ ?>