<div class="modal fade update-promotion" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Cập nhật chương trình khuyễn mãi</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('promotion.update', ['id' => $promotion->id])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="title">Tên chươn trình khuyến mãi</label>
                        <input type="text" class="form-control" id="title" placeholder="Nhập tên chương trình" name="title" value="<?php echo e($promotion->title); ?>">
                    </div>
                    <div class="form-group">
                        <label for="index">Điểm tích lũy</label>
                        <input type="text" class="form-control" id="index" placeholder="Nhập điểm tích lũy" name="point" value="<?php echo e($promotion->reward_point); ?>">
                    </div>
                    <div class="form-group">
                        <label for="description">Nội dung khuyến mãi</label>
                        <input type="text" class="form-control" id="description" placeholder="Nhập nội dung khuyến mãi" name="description" value="<?php echo e($promotion->description); ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Lưu</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\mottolial_8x\resources\views/admin/promotion/_update.blade.php ENDPATH**/ ?>