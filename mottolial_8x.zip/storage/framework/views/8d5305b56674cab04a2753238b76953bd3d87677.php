<div class="modal fade update-user" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Cập nhật user</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('admin.user.update', ['id' => $user->id])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="username">Tên user</label>
                        <input type="text" class="form-control" id="username" placeholder="Nhập tên user" name="username" value="<?php echo e($user->name); ?>">
                    </div>
                    <div class="form-group">
                        <label for="phone">Số điện thoại</label>
                        <input type="text" class="form-control" id="phone" placeholder="Nhập số điện thoại" name="phone" value="<?php echo e($user->phone); ?>">
                    </div>
                    <div class="form-group">
                        <label for="password">Mật khẩu</label>
                        <input type="text" class="form-control" id="password" placeholder="Nhập mật khẩu" name="password" >
                    </div>
                    <div class="form-group">
                        <label for="address">Địa chỉ</label>
                        <textarea name="address" id="address" class="form-control" rows="10" placeholder="Nhập địa chỉ" ><?php echo e($user->detail_address); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="role">Chọn vai trò</label>
                        <div class="d-flex justify-content-between">
                            <?php $__currentLoopData = config('core.roles'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check my-0 mr-5">
                                    <label class="form-check-label">
                                        <input type="radio" class="form-check-input" name="role" id="" value="<?php echo e($key); ?>" <?php if($user->hasRole($key)): ?> checked <?php endif; ?>> <?php echo e($role); ?> <i class="input-helper"></i></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success">Cập nhật</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\mottolial_8x\resources\views/admin/user/_update.blade.php ENDPATH**/ ?>