@extends('layouts.admin')

@section('content')
    <div class="alert alert-success" role="alert">
        Xin chào admin
    </div>
@stop
