<?php

return [
    'roles' => [
        'admin' => 'Admin',
        'staff' => 'Staff',
        'financial' => 'Financial',
        'user' => 'User'
    ],

    /*
     * Admin mặc định khi chạy seed
     * Quản trị toàn hệ thông
     */
    'admin' => [
        'phone' => '0123456',
        'pass' => '123456'
    ]
];
