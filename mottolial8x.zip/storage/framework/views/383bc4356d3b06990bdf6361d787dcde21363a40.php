<div class="d-flex justify-content-between wp-classify">
    <div class="item-add">
        <input type="text" name="classifyName[]" placeholder="Nhập tên phân loại" class="form-control">
    </div>
    <div class="item-add">
        <input type="text" name="price[]" placeholder="Nhập giá sản phẩm" class="form-control">
    </div>
    <div class="item-add">
        <input type="text" name="sale_price[]" placeholder="Nhập giá khuyến mại" class="form-control">
    </div>
    <div class="item-add">
        <input type="number" name="amount[]" placeholder="Số lượng" class="form-control">
    </div>
    <div class="delete-item" onclick="deleteItem(this)">
        <i class="mdi mdi-delete"></i>
    </div>
</div>
<?php /**PATH D:\app\xampp\htdocs\mottolial8x\resources\views/admin/product/_classify.blade.php ENDPATH**/ ?>