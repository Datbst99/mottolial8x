<?php $__env->startSection('title', 'Quản lý sản phẩm'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h3 class="page-title"> Quản lý sản phẩm </h3>
        <?php echo e(Breadcrumbs::render('admin.product')); ?>

    </div>
    <div class="card">
        <div class="card-body">
            <div class="card-title">Filters</div>
            <div>
                <?php echo Form::open(['method' => 'get']); ?>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <button class="btn btn-sm btn-default dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown</button>
                                    <div class="dropdown-menu" style="">
                                        <a class="dropdown-item" href="#">Action</a>
                                        <a class="dropdown-item" href="#">Another action</a>
                                        <a class="dropdown-item" href="#">Something else here</a>
                                        <div role="separator" class="dropdown-divider"></div>
                                        <a class="dropdown-item" href="#">Separated link</a>
                                    </div>
                                </div>
                                <input type="text" class="form-control" placeholder="Nhập tên sản phẩm..." value="<?php echo e(request()->get('search')); ?>" name="search">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <?php echo Form::select('category', $categories, null, ['class' => 'form-control', 'placeholder' => '--Chọn danh mục--']); ?>

                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-fw">Tìm kiếm</button>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
    <div class="card mt-4">
        <div class="card-body">
            <div class="d-flex justify-content-end mb-3">
                <a  class="btn btn-primary btn-fw d-flex align-items-center" href="<?php echo e(route('product.create')); ?>"> <i class="mdi mdi-plus"></i> Thêm sản phẩm</a>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th>
                            <input type="checkbox" class="">
                        </th>
                        <th>Thumbnail</th>
                        <th>Tên sản phẩm </th>
                        <th>Phân loại</th>
                        <th>Số lượng</th>
                        <th>Giá</th>
                        <th>Giá khuyến mại</th>
                        <th>Mã sản phẩm</th>
                        <th>Người tạo</th>
                        <th>Ngày tạo</th>
                        <th style="width: 10px">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><input type="checkbox" class=""></td>
                                <td class="text-nowrap">
                                    <img src="<?php echo e($product->thumbnail); ?>" alt="<?php echo e($product->name); ?>" style="width: 100px; height: 100px">
                                </td>
                                <td class="text-nowrap"><?php echo e($product->name); ?></td>
                                <td class="text-nowrap"><?php echo e($product->classifyName()); ?></td>
                                <td class="text-nowrap"><?php echo e($product->classifyAmount()); ?></td>
                                <td class="text-nowrap"><?php echo e($product->classifyPrice()); ?> đ</td>
                                <td class="text-nowrap"><?php echo e($product->classifySalePrice()); ?> đ</td>
                                <td class="text-nowrap"><?php echo e($product->code); ?></td>
                                <td class="text-nowrap"><?php echo e($product->createBy()); ?></td>
                                <td class="text-nowrap"><?php echo e($product->created_at); ?></td>
                                <td class="text-center"><i class="mdi mdi-border-color"></i></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="custom-paginate d-flex justify-content-end mt-3">
                <?php echo e($products->links()); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\app\xampp\htdocs\mottolial8x\resources\views/admin/product/index.blade.php ENDPATH**/ ?>